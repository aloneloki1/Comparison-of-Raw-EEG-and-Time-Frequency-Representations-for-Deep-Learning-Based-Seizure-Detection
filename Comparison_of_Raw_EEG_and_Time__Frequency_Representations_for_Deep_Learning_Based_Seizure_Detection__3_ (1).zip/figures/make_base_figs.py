import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":9,"font.family":"serif","axes.spines.top":False,"axes.spines.right":False,"savefig.dpi":300,"savefig.bbox":"tight"})
col=["#1f4e9c","#d9622b"]
# Fig 8 confusion matrices
fig,axs=plt.subplots(1,2,figsize=(6.6,2.7))
for ax,(t,cm,cmap) in zip(axs,[("(a) Raw EEG + 1D CNN",np.array([[64,0],[12,52]]),"Blues"),("(b) STFT + 2D CNN",np.array([[60,4],[0,64]]),"Oranges")]):
    pct=cm/cm.sum(1,keepdims=True); ax.imshow(pct,cmap=cmap,vmin=0,vmax=1.2)
    for i in range(2):
        for j in range(2):
            ax.text(j,i-.1,str(cm[i,j]),ha="center",va="center",fontsize=13,fontweight="bold",color="white" if pct[i,j]>.7 else "black")
            ax.text(j,i+.22,f"{100*pct[i,j]:.1f}%",ha="center",va="center",fontsize=7,color="white" if pct[i,j]>.7 else "black")
    ax.set_xticks([0,1],["Non-seiz.","Seizure"]); ax.set_yticks([0,1],["Non-seiz.","Seizure"],rotation=90,va="center")
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(t,fontsize=9)
    for s in ax.spines.values(): s.set_visible(True)
fig.tight_layout(); fig.savefig("fig08_confusion_matrices.pdf"); plt.close()
# Fig 12
fig,(a,b)=plt.subplots(1,2,figsize=(7.2,2.8),gridspec_kw={"width_ratios":[1.5,1]})
mets=["Accuracy","Precision","Sensitivity","Specificity","F1-score"]
raw=[.9062,1.0,.8125,1.0,.8966]; stft=[.9688,.9412,1.0,.9375,.9697]; x=np.arange(5)
for i,(v,n) in enumerate([(raw,"Raw EEG + 1D CNN"),(stft,"STFT + 2D CNN")]):
    bars=a.bar(x+(i-.5)*.36,v,.36,color=col[i],hatch=["","//"][i],edgecolor="k",lw=.5,label=n)
    for r,val in zip(bars,v): a.text(r.get_x()+r.get_width()/2,val+.005,f"{val:.3f}",ha="center",fontsize=6.5,rotation=90,va="bottom")
a.set_ylim(.7,1.08); a.set_xticks(x,mets,fontsize=7.5); a.set_ylabel("Score (axis starts at 0.70)"); a.legend(frameon=False,fontsize=7,loc="lower left")
a.set_title("(a) Threshold-based metrics",fontsize=8.5)
conv=[35264,92672]; dense=[8321,8321]; y=[1,0]
b.barh(y,conv,color="#4a7ab8",edgecolor="k",lw=.5,label="Convolutional blocks"); b.barh(y,dense,left=conv,color="#e0a030",edgecolor="k",lw=.5,label="Dense head")
b.text(35264+8321+1500,1,"43,585",va="center",fontsize=7.5); b.text(92672+8321+1500,0,"100,993",va="center",fontsize=7.5)
b.set_yticks(y,["1D CNN","2D CNN"]); b.set_xlim(0,150000); b.set_xlabel("Trainable parameters"); b.legend(frameon=False,fontsize=7,loc="lower right",bbox_to_anchor=(1.05,.45))
b.set_title("(b) Parameter composition",fontsize=8.5)
fig.tight_layout(); fig.savefig("fig12_metrics_and_parameters.pdf"); plt.close()
# Fig 13 sample accounting
fig,ax=plt.subplots(figsize=(6.0,1.9))
rows=[("Reported split",[("Train 160",160,"#4a7ab8"),("Test 40",40,"#d9622b")]),
      ("Implied by curves",[("Train 128",128,"#4a7ab8"),("Val 32",32,"#e0a030"),("Test 40",40,"#d9622b")]),
      ("Confusion matrices",[("n = 128",128,"#6aa84f")])]
for i,(lab,segs) in enumerate(rows):
    left=0; yy=2-i
    for t,w,c in segs:
        ax.barh(yy,w,left=left,color=c,edgecolor="k",lw=.6,height=.6); ax.text(left+w/2,yy,t,ha="center",va="center",fontsize=8,color="white" if c!="#e0a030" else "black"); left+=w
ax.set_yticks([2,1,0],[r[0] for r in rows]); ax.set_xlim(0,200); ax.set_xlabel("Number of samples")
fig.tight_layout(); fig.savefig("fig13_sample_accounting.pdf"); plt.close()
