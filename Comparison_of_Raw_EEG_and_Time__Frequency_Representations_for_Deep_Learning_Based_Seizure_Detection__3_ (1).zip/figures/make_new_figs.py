import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from math import sqrt
plt.rcParams.update({"font.size":9,"font.family":"serif","axes.spines.top":False,"axes.spines.right":False,"savefig.dpi":300,"savefig.bbox":"tight"})
C={"raw":"#1f4e9c","stft":"#d9622b"}
cm={"Raw EEG + 1D CNN":dict(TP=52,TN=64,FP=0,FN=12),"STFT + 2D CNN":dict(TP=64,TN=60,FP=4,FN=0)}
col=[C["raw"],C["stft"]]; mk=["o","s"]
def m(d):
    TP,TN,FP,FN=d["TP"],d["TN"],d["FP"],d["FN"]; n=TP+TN+FP+FN
    sens=TP/(TP+FN); spec=TN/(TN+FP); prec=TP/(TP+FP); npv=TN/(TN+FN)
    mcc=(TP*TN-FP*FN)/sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))
    return dict(n=n,acc=(TP+TN)/n,sens=sens,spec=spec,prec=prec,npv=npv,f1=2*prec*sens/(prec+sens),
                bal=(sens+spec)/2,J=sens+spec-1,mcc=mcc,fpr=1-spec,fnr=1-sens)
def wilson(k,n,z=1.96):
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/d; return c-h,c+h
M={k:m(v) for k,v in cm.items()}
for k,v in M.items(): print(k,{a:round(b,4) for a,b in v.items()})
names=list(cm)
# Fig14 error counts
fig,ax=plt.subplots(figsize=(4.2,2.8)); lab=["TP","TN","FP","FN"]; x=np.arange(4); w=.36
for i,k in enumerate(names):
    v=[cm[k][l] for l in lab]; b=ax.bar(x+(i-.5)*w,v,w,label=k,color=col[i],hatch=["","//"][i],edgecolor="k",lw=.5)
    for r,val in zip(b,v): ax.text(r.get_x()+r.get_width()/2,val+1,str(val),ha="center",fontsize=8)
ax.set_xticks(x,lab); ax.set_ylabel("Number of test examples"); ax.set_ylim(0,78); ax.legend(frameon=False,fontsize=8)
fig.savefig("fig14_error_counts.pdf"); fig.savefig("fig14_error_counts.png"); plt.close()
# Fig15 ROC-space
fig,ax=plt.subplots(figsize=(3.6,3.4))
ax.plot([0,1],[0,1],":",c="gray",label="Chance")
ax.plot([0,0,1],[0,1,1],"--",c="k",lw=1,label="Curve implied by AUC = 1.000\n(reported, unverified)")
for i,k in enumerate(names):
    ax.scatter(M[k]["fpr"],M[k]["sens"],s=70,marker=mk[i],c=col[i],edgecolor="k",zorder=5,label=f"{k}\n(FPR={M[k]['fpr']:.3f}, TPR={M[k]['sens']:.3f})")
ax.set_xlim(-.03,1.0); ax.set_ylim(0,1.04); ax.set_xlabel("False-positive rate (1 - specificity)"); ax.set_ylabel("True-positive rate (sensitivity)")
ax.legend(frameon=False,fontsize=6.5,loc="lower right")
fig.savefig("fig15_roc_operating_points.pdf"); fig.savefig("fig15_roc_operating_points.png"); plt.close()
# Fig16 Wilson CI
fig,ax=plt.subplots(figsize=(4.4,2.9))
items=[("Accuracy",lambda d:d["TP"]+d["TN"],lambda d:sum(d.values())),("Sensitivity",lambda d:d["TP"],lambda d:d["TP"]+d["FN"]),
       ("Specificity",lambda d:d["TN"],lambda d:d["TN"]+d["FP"]),("Precision",lambda d:d["TP"],lambda d:d["TP"]+d["FP"])]
for j,(nm,kf,nf) in enumerate(items):
    for i,k in enumerate(names):
        kk,nn=kf(cm[k]),nf(cm[k]); p=kk/nn; lo,hi=wilson(kk,nn); y=len(items)-1-j+(.15 if i==0 else -.15)
        ax.errorbar(p,y,xerr=[[p-lo],[hi-p]],fmt=mk[i],c=col[i],capsize=3,ms=5,label=k if j==0 else None)
        print(nm,k,round(p,4),round(lo,3),round(hi,3))
ax.set_yticks(range(len(items)),[n for n,_,_ in items][::-1]); ax.set_xlabel("Value with Wilson 95% interval"); ax.set_xlim(.6,1.02)
ax.legend(frameon=False,fontsize=8,loc="lower left"); ax.grid(axis="x",alpha=.3)
fig.savefig("fig16_wilson_intervals.pdf"); fig.savefig("fig16_wilson_intervals.png"); plt.close()
# Fig17 radar + balanced metrics
fig=plt.figure(figsize=(6.6,3.0)); ax=fig.add_subplot(1,2,1,projection="polar")
keys=[("acc","Accuracy"),("prec","Precision"),("sens","Sensitivity"),("spec","Specificity"),("f1","F1")]
ang=np.linspace(0,2*np.pi,len(keys),endpoint=False).tolist(); ang+=ang[:1]
for i,k in enumerate(names):
    v=[M[k][a] for a,_ in keys]; v+=v[:1]; ax.plot(ang,v,c=col[i],marker=mk[i],ms=4,label=k); ax.fill(ang,v,color=col[i],alpha=.12)
ax.set_xticks(ang[:-1],[b for _,b in keys],fontsize=8); ax.set_ylim(.7,1.0); ax.set_yticks([.8,.9,1.0]); ax.set_yticklabels(["0.8","0.9","1.0"],fontsize=7)
ax.legend(frameon=False,fontsize=7,loc="upper center",bbox_to_anchor=(.5,-.08)); ax.set_title("(a) Metric profile (radius starts at 0.70)",fontsize=8,pad=14)
ax2=fig.add_subplot(1,2,2); k2=[("bal","Balanced\naccuracy"),("J","Youden's J"),("mcc","MCC"),("npv","NPV")]; x=np.arange(4)
for i,k in enumerate(names):
    v=[M[k][a] for a,_ in k2]; b=ax2.bar(x+(i-.5)*.36,v,.36,color=col[i],hatch=["","//"][i],edgecolor="k",lw=.5)
    for r,val in zip(b,v): ax2.text(r.get_x()+r.get_width()/2,val+.01,f"{val:.3f}",ha="center",fontsize=6.5,rotation=90,va="bottom")
ax2.set_xticks(x,[b for _,b in k2],fontsize=8); ax2.set_ylim(0,1.25); ax2.set_ylabel("Score"); ax2.set_title("(b) Imbalance-robust metrics",fontsize=8)
fig.tight_layout(); fig.savefig("fig17_radar_and_robust_metrics.pdf"); fig.savefig("fig17_radar_and_robust_metrics.png"); plt.close()
